#!/bin/bash

# This script will be downloaded off of git/somwehere else and will setup the ubuntu 22 environment with all the tools necessary.

GIT_INSTALLED=0


if [ "$(id -u)" != "0" ]; then
    echo "This script must be run as root"
    exit 1
fi

install_git() {
    echo "[+] Installing Git..."
    sudo apt install -y git
    
    # Verify installation
    echo "[+] Verifying Git installation..."
    git --version
    
    # Success message
    echo "[+] Git has been successfully installed!"
}

get_scripts() {

}

run_hardening_scripts() {

}

setup_ansible() {
    echo "[+] Installing dependencies..."
    apt install -y python3 python3-pip
    
    echo "[+] Installing Ansible with pip..."
    python3 install --upgrade pip
    python3 install ansible
    
    echo "[+] Verifying Ansible installation..."
    ansible --version
    
    echo "Ansible has been successfully installed via pip!"
}


setup_rsyslog() {

}

setup_auditd() {

}

setup_coordinate() {

}

get_scripts
run_hardening_script
setup_coordinate
deploy_scripts
setup_ansible
setup_auditd
setup_rsyslog
