if [ "$(id -u)" != "0" ]; then
    echo "This script must be run as root"
    exit 1
fi

REMOTE=1 #if you are running this script remotely (Ansible/SSHPass/Coordinate)
ADMIN_PASSWORD="Ch@ng3_m3"

change_root_password() {
    echo "[+] Changing root password..."
    if [[ REMOTE -eq 1 ]]; then
	echo "root:$ADMIN_PASSWORD" | chpasswd
    else
	echo -n "Root Password: "; read -r pass
	echo "root:$pass" | chpasswd
    fi
    echo "Successfully changed root password"
}

remove_admin_users() {
    ADMIN1="dawg" #These are locked by default
    ADMIN2="bak"
    PASS1="Ch@ng3_m3"
    PASS2="Ch@ng3_m3"
    
    echo "[+] Changing admin users..."
    users=$(cat /etc/group | grep sudo | tr ":" " " | cut -d' ' -f4- | tr "," " ")
    echo "Current admin users: $users"

    echo "[+] Removing all admin users"
    #removing all admin users
    for user in $users; do
	gpasswd -d "$user" sudo
    done

    echo "[+] Adding in new and backup admin"
    #adding in admin users
    useradd "$ADMIN1"
    useradd "$ADMIN2"

    echo "[+] Updating password on accounts"
    #unlocks account by giving them password
    echo "$ADMIN1:$PASS1" | chpasswd
    echo "$ADMIN2:$PASS2" | chpasswd

    echo "[+] Add new admins to the sudo group"
    #giving admin privs to new users
    usermod -aG sudo "$ADMIN1"
    usermod -aG sudo "$ADMIN2"
    
    echo $(cat /etc/group | grep sudo | tr ":" " " | cut -d' ' -f4-)
}

harden_sudoers() {
    echo "[+] Hardening Sudoers file..."
    echo "RGVmYXVsdHMgZW52X3Jlc2V0IApEZWZhdWx0cyBtYWlsX2JhZHBhc3MgCkRlZmF1bHRzIHNlY3VyZV9wYXRoPS91c3Ivc2JpbjovdXNyL2Jpbjovc2JpbjovYmluIApyb290IEFMTD0oQUxMOkFMTCkgQUxMIAolYWRtaW4gQUxMPShBTEwpIEFMTCAKJXN1ZG8gQUxMPShBTEw6QUxMKSBBTEwK" | base64 -d > /etc/sudoers
    find /etc/sudoers.d/ -mindepth 1 -delete
}

disable_cron() {
    echo "[+] Disabling Cron"
    systemctl stop cron
    systemctl disable cron
}

remove_profiles() {
    echo "[+] Removing all profiles"
    # shoutouts DSU for the script
    mv /etc/prof{i,y}le.d 2>/dev/null
    mv /etc/prof{i,y}le 2>/dev/null
#    for f in '.profile' '.bashrc' '.bash_login'; do
#	find /home /root -name "$f" -exec rm {} \;
#    done
}

remove_compilers() {
    echo "[+] Removing Compilers and disabling kernel module insertion"
    /sbin/sysctl -w kernel.modules_disabled=1
    if command -v gcc &> /dev/null; then
	rm `which gcc`
    else
	echo "  - gcc not found"
    fi
}


reset_pam() {
    echo "[+] Resetting Pam Configs"
    DEBIAN_FRONTEND=noninteractive 
    pam-auth-update --force
    apt-get -y --reinstall install libpam-runtime libpam-modules
}

disable_history() {
    echo "[+] Disabling root history"
    ln -sf /dev/null /root/.bash_history
}

clear_ld_preload() {
    echo "[+] Disabling LD Preload"
    echo "" > /etc/ld.so.preload
    export LD_PRELOAD=""

}

harden_sshd() {
    echo "[+] Hardening SSHD config..."
    echo "UGVybWl0Um9vdExvZ2luIG5vClB1YmtleUF1dGhlbnRpY2F0aW9uIG5vClVzZVBBTSBubyAKVXNlRE5TIG5vCkFkZHJlc3NGYW1pbHkgaW5ldApNYXRjaCBBZGRyZXNzIDEwLjY2LjEuNAogICAgUGVybWl0Um9vdExvZ2luIHllcwpNYXRjaCBBZGRyZXNzIDEwLjMuMS4wLzI0CiAgICBQZXJtaXRSb290TG9naW4geWVzCg==" | base64 -d > /etc/ssh/sshd_config
    chattr +i /etc/ssh/sshd_config
}

echo "Running Hardening Scripts..."
change_root_password
remove_admin_users
harden_sudoers
harden_sshd
disable_history
clear_ld_preload
disable_cron


