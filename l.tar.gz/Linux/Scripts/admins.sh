# !/bin/bash

#this script adds a bunch of admin users. Mainly to test if the remove admin functionality works but ig it can work as red team stuffs? probably not though

PREFIX="dawg"
numAdmins=15

for ((i = 0; i < "$numAdmins"; i++)); do
    SUFFIX=$(cat /dev/random | head -n 1 | xxd -p | head -n 1 | cut -c 1-8)
    USER="$PREFIX$SUFFIX"
    useradd "$USER"
    echo "$USER:password" | chpasswd
    usermod -aG sudo "$USER"
    usermod -aG users "$USER"
done
