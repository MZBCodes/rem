#script to backup mysql database
MYSQL_USER="USER"
MYSQL_PASS="PASS"
