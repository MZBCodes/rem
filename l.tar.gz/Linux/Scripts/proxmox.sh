# This is the hardening script for the ubuntu ssh machine

if [ "$(id -u)" != "0" ]; then
    echo "This script must be run as root"
    exit 1
fi

REMOTE=1
ADMIN_PASSWORD="7(RegretFactor"

change_root_password() {
    echo "[+] Changing root password..."
    if [[ REMOTE -eq 1 ]]; then
        echo "root:$ADMIN_PASSWORD" | chpasswd
    else
        echo -n "Root Password: "; read -r pass
        echo "root:$pass" | chpasswd
    fi
    echo "Successfully changed root password"
}


setup_firewall() {
    echo "[+] Disabling firewall wrappers..."
    systemctl stop firewalld 2>/dev/null
    systemctl disable firewalld 2>/dev/null
    
    systemctl stop ufw 2>/dev/null
    systemctl disable ufw 2>/dev/null
    
    systemctl stop nftables 2>/dev/null
    systemctl disable nftables 2>/dev/null
    
    echo "[+] Flushing existing iptables rules..."
    iptables -F
    iptables -X
    iptables -Z

    echo "[+] Setting up new iptables rules..."

    iptables -P INPUT DROP
    iptables -P FORWARD DROP
    iptables -P OUTPUT ACCEPT
    
    iptables -A INPUT -i lo -j ACCEPT
    iptables -A OUTPUT -o lo -j ACCEPT
    
    iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT    

    iptables -A INPUT -p tcp --dport 22 -m conntrack --ctstate NEW -j ACCEPT

    iptables -A INPUT -p tcp --dport 8006 -m conntrack --ctstate NEW -j ACCEPT
    
    echo "[+] Saving iptables rules..."
    if command -v iptables-save &>/dev/null; then
	iptables-save > /etc/iptables.rules
	echo "iptables-save completed."
    else
	echo "iptables-save not found, rules may not persist after reboot."
    fi
}

echo "Running Hardening Scripts..." 
setup_firewall
change_root_password
