# <password> <user> <ip> <script_name>

run_scripts() {
    local password="$1"
    local user="$2"
    local ip="$3"
    local script_name="$4"

    echo "$password $user $ip $script_name"

    # Copy the script to the remote machine
    sshpass -p "$password" scp "$script_name" "$user@$ip:/tmp/"

    # Execute the script remotely using sudo
    sshpass -p "$password" ssh -o StrictHostKeyChecking=no "$user@$ip" "echo '$password' | sudo -S bash /tmp/$script_name"
}

run_scripts "Ch@ng3_m3" "dawg" "10.3.1.4" "nothing.sh"
 
 
