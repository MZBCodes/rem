#!/bin/bash
echo 'hellotest' > /home/dawg/test.txt
