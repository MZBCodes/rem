# This is the hardening script for the ubuntu ssh machine

if [ "$(id -u)" != "0" ]; then
    echo "This script must be run as root"
    exit 1
fi

REMOTE=1
ADMIN_PASSWORD="4-FrontIndian"

change_root_password() {
    echo "[+] Changing root password..."
    if [[ REMOTE -eq 1 ]]; then
        echo "root:$ADMIN_PASSWORD" | chpasswd
    else
        echo -n "Root Password: "; read -r pass
        echo "root:$pass" | chpasswd
    fi
    echo "Successfully changed root password"
}

add_admin_users() {
    ADMIN1="dawg"
    PASS1="1-MinimalHarmony"

    echo "[+] Adding in backup admin"
    #adding in admin users
    useradd "$ADMIN1"
    
    echo "[+] Updating password on accounts"

    #unlocks account by giving them password
    echo "$ADMIN1:$PASS1" | chpasswd
    
    ECHO "[+] Add new admins to the sudo group"
    usermod -aG wheel "$ADMIN1"
}

remove_admin_users() {
    users=$(grep '^wheel:' /etc/group | tr ":" " " | cut -d' ' -f4- | tr "," " ")
    echo "Current admin users: $users"

    echo "[+] Removing old admin users"
    for user in $users; do
        if [[ "$user" == "whiteteam" || "$user" == "blackteam" ]]; then
            continue
        fi
        gpasswd -d "$user" wheel
    done
    echo $(grep wheel /etc/group | tr ":" " " | cut -d' ' -f4-)

}
setup_firewall() {
    echo "[+] Disabling firewall wrappers..."
    systemctl stop firewalld 2>/dev/null
    systemctl disable firewalld 2>/dev/null
    
    systemctl stop ufw 2>/dev/null
    systemctl disable ufw 2>/dev/null
    
    systemctl stop nftables 2>/dev/null
    systemctl disable nftables 2>/dev/null
    
    echo "[+] Flushing existing iptables rules..."
    iptables -F
    iptables -X
    iptables -Z

    echo "[+] Setting up new iptables rules..."
    
    iptables -P INPUT DROP
    iptables -P FORWARD DROP
    iptables -P OUTPUT ACCEPT
    
    iptables -A INPUT -i lo -j ACCEPT
    iptables -A OUTPUT -o lo -j ACCEPT
    
    iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT    

    iptables -A INPUT -p tcp --dport 22 -m conntrack --ctstate NEW -j ACCEPT

    iptables -A INPUT -p tcp --dport 3000 -m conntrack --ctstate NEW -j ACCEPT
    iptables -A INPUT -p tcp --dport 80 -m conntrack --ctstate NEW -j ACCEPT
    iptables -A INPUT -p tcp --dport 4000 -m conntrack --ctstate NEW -j ACCEPT

    echo "[+] Saving iptables rules..."
    if command -v iptables-save &>/dev/null; then
	iptables-save > /etc/iptables.rules
	echo "iptables-save completed."
    else
	echo "iptables-save not found, rules may not persist after reboot."
    fi
}

fix_sudoers() {
	echo "RGVmYXVsdHMgZW52X3Jlc2V0IApEZWZhdWx0cyBtYWlsX2JhZHBhc3MgCkRlZmF1bHRzIHNlY3VyZV9wYXRoPSIvdXNyL3NiaW46L3Vzci9iaW46L3NiaW46L2JpbiIgCnJvb3QgQUxMPShBTEw6QUxMKSBBTEwgCiVhZG1pbiBBTEw9KEFMTCkgQUxMIAold2hlZWwgQUxMPShBTEw6QUxMKSBBTEwK" | base64 -d > /etc/sudoers
}

echo "Running Hardening Scripts..." 
setup_firewall
change_root_password
remove_admin_users
add_admin_users
fix_sudoers

rm -- "$0"
