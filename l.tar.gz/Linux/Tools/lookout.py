# !/usr/pppbin/python3

from scapy.all import *
import logging
from datetime import datetime

def extract_domain_from_http(packet):
    log = ""
    if packet.haslayer(Raw):
        payload = packet[Raw].load
        if b'HTTP/' in payload and (b'GET' in payload or b'POST' in payload):  # Check if it's an HTTP packet
            try:
                payload = payload.decode('utf-8', errors='ignore')
            except UnicodeDecodeError:
                return
            domain = ""
            request = ""
            for line in payload.splitlines():
                if line.startswith("GET") or line.startswith("POST"):
                    request = line.strip()
                if line.startswith("Host:"):
                    domain = line.split(":")[1].strip()
            now = datetime.now()
            currentTime = now.strftime('%Y-%m-%d %H:%M:%S')
            log = domain + " - " + "[" + currentTime + "] " + request
            with open("packet_log.txt", "a") as f:
                print(log)
                f.write(log + "\n")
            
def log_packet(packet):
    extract_domain_from_http(packet)

sniff(iface="eth0", prn=log_packet)
