import requests
import os

response = requests.get("https://ip-ranges.us5.datadoghq.com/")
addr_data = response.json()

addr_pool = [addr_data["agents"]["prefixes_ipv4"], addr_data["api"]["prefixes_ipv4"], addr_data["apm"]["prefixes_ipv4"], addr_data["global"]["prefixes_ipv4"], addr_data["logs"]["prefixes_ipv4"], addr_data["orchestrator"]["prefixes_ipv4"], addr_data["process"]["prefixes_ipv4"], addr_data["remote-configuration"]["prefixes_ipv4"], addr_data["synthetics"]["prefixes_ipv4"], addr_data["webhooks"]["prefixes_ipv4"]]

sublist_i = 0
with open("datadog.txt", "w") as f:
    for addr_sublist in addr_pool:
        for addr_i in range(len(addr_sublist)):
            f.write(f'  - name: "Allow inbound Datadog {sublist_i} {addr_i}"\n\
    pfsense_rule:\n\
      name: "Allow inbound Datadog {sublist_i} {addr_i}"\n\
      action: pass\n\
      interface: wan\n\
      ipprotocol: inet\n\
      protocol: tcp/udp\n\
      source: {addr_sublist[addr_i]}\n\
      destination: any\n\
      state: present\n')
            f.write(f'  - name: "Allow outbound Datadog {sublist_i} {addr_i}"\n\
    pfsense_rule:\n\
      name: "Allow outbound Datadog {sublist_i} {addr_i}"\n\
      action: pass\n\
      interface: wan\n\
      ipprotocol: inet\n\
      protocol: tcp/udp\n\
      source: any\n\
      destination: {addr_sublist[addr_i]}\n\
      state: present\n')
        sublist_i += 1 

